(function(window, undefined) {

  var jimLinks = {
    "89912a05-afc3-41d4-84b2-2956d34f725f" : {
      "Hotspot_1" : [
        "55956c42-bb44-4ffb-b6e1-9bab21d74c22"
      ],
      "Hotspot_5" : [
        "f76382bb-5b34-4b25-a5cc-84419b21f470"
      ],
      "Hotspot_2" : [
        "2494fc43-c886-4267-99eb-524da06d297f"
      ]
    },
    "55956c42-bb44-4ffb-b6e1-9bab21d74c22" : {
      "Hotspot_1" : [
        "55956c42-bb44-4ffb-b6e1-9bab21d74c22"
      ],
      "Hotspot_3" : [
        "7d5a14e4-3df5-4258-b1fd-80ab5f7d0b2f"
      ],
      "Hotspot_4" : [
        "7d5a14e4-3df5-4258-b1fd-80ab5f7d0b2f"
      ],
      "Hotspot_5" : [
        "f76382bb-5b34-4b25-a5cc-84419b21f470"
      ],
      "Hotspot_6" : [
        "7d5a14e4-3df5-4258-b1fd-80ab5f7d0b2f"
      ],
      "Hotspot_2" : [
        "2494fc43-c886-4267-99eb-524da06d297f"
      ]
    },
    "f76382bb-5b34-4b25-a5cc-84419b21f470" : {
      "Hotspot_1" : [
        "55956c42-bb44-4ffb-b6e1-9bab21d74c22"
      ],
      "Hotspot_5" : [
        "f76382bb-5b34-4b25-a5cc-84419b21f470"
      ],
      "Hotspot_2" : [
        "2494fc43-c886-4267-99eb-524da06d297f"
      ]
    },
    "7d5a14e4-3df5-4258-b1fd-80ab5f7d0b2f" : {
      "Hotspot_1" : [
        "55956c42-bb44-4ffb-b6e1-9bab21d74c22"
      ],
      "Hotspot_2" : [
        "55956c42-bb44-4ffb-b6e1-9bab21d74c22"
      ],
      "Hotspot_3" : [
        "55956c42-bb44-4ffb-b6e1-9bab21d74c22"
      ],
      "Hotspot_4" : [
        "55956c42-bb44-4ffb-b6e1-9bab21d74c22"
      ],
      "Hotspot_5" : [
        "f76382bb-5b34-4b25-a5cc-84419b21f470"
      ],
      "Hotspot_6" : [
        "89912a05-afc3-41d4-84b2-2956d34f725f"
      ],
      "Hotspot_7" : [
        "2494fc43-c886-4267-99eb-524da06d297f"
      ]
    },
    "2494fc43-c886-4267-99eb-524da06d297f" : {
      "Hotspot_5" : [
        "f76382bb-5b34-4b25-a5cc-84419b21f470"
      ],
      "Hotspot_1" : [
        "55956c42-bb44-4ffb-b6e1-9bab21d74c22"
      ],
      "Hotspot_2" : [
        "55956c42-bb44-4ffb-b6e1-9bab21d74c22"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);