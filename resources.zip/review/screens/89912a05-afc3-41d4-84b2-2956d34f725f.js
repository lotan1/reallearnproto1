var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1024" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589075344964.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589075344964-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589075344964-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-89912a05-afc3-41d4-84b2-2956d34f725f" class="screen growth-both devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="51" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/89912a05-afc3-41d4-84b2-2956d34f725f-1589075344964.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/89912a05-afc3-41d4-84b2-2956d34f725f-1589075344964-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/89912a05-afc3-41d4-84b2-2956d34f725f-1589075344964-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="1030px" datasizeheight="583px" dataX="0" dataY="0"   alt="image">\
          <img src="./images/2d0c2f84-99ec-4aff-81dc-3aa60f58c219.jpg" />\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="1033px" datasizeheight="526px" dataX="3" dataY="572"   alt="image">\
          <img src="./images/93a9fc7a-fe2b-400f-ac94-637032fbb56b.jpg" />\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="1038px" datasizeheight="580px" dataX="0" dataY="1098"   alt="image">\
          <img src="./images/e39946c9-075d-4659-8c23-a88ef6814a1b.jpg" />\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="440px" datasizeheight="40px" dataX="417" dataY="10"  >\
          <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="123px" datasizeheight="32px" dataX="893" dataY="12"  >\
          <div class="clickableSpot"></div>\
      </div>\
      <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"  rotationdeg="90" datasizewidth="429px" datasizeheight="11px" dataX="747" dataY="299" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 5 L 429 5"  marker-end="url(#end-marker-s-Line_1">\
                      </path>\
                  </g>\
              </g>\
              <defs>\
      			<marker id="end-marker-s-Line_1" class="open endmarker" orient="0" stroke-width="0px" viewBox="0 0 100 100" refY="50" preserveAspectRatio="none" markerUnits="userSpaceOnUse">\
      				<path d="M 39.688716 40.466926 39.818418 60.051881 7.9118028 79.24773 C -6.6058565 88.636494 5.3977603 106.07944 19.844358 97.146562 L 99.610893 50.324254 21.53048 3.7613489 C 4.631474 -8.1505951 -6.7257532 14.353316 7.6523994 20.881971 Z"></path>\
      			</marker>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="22px" dataX="914" dataY="19" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">משתמש</span></div></div></div></div>\
      <div id="s-Text_10" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="152px" datasizeheight="42px" dataX="28" dataY="9" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_10_0">ReaLearn</span></div></div></div></div>\
      <div id="s-Text_11" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="130px" datasizeheight="22px" dataX="45" dataY="79" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_11_0">קישור לעוד חומרים</span></div></div></div></div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="145px" datasizeheight="28px" dataX="28" dataY="76"  >\
          <div class="clickableSpot"></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;