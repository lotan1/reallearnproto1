var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1024" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589075344964.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589075344964-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589075344964-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-2494fc43-c886-4267-99eb-524da06d297f" class="screen growth-both devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="about" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/2494fc43-c886-4267-99eb-524da06d297f-1589075344964.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/2494fc43-c886-4267-99eb-524da06d297f-1589075344964-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/2494fc43-c886-4267-99eb-524da06d297f-1589075344964-ie8.css" /><![endif]-->\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="1024px" datasizeheight="600px" dataX="0" dataY="0"   alt="image">\
          <img src="./images/245b0f6f-6076-418b-aa29-e5e14e86d851.jpg" />\
      </div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="733px" datasizeheight="576px" dataX="159" dataY="54"   alt="image">\
          <img src="./images/9919db11-b136-4f9a-bd0a-fdd21336dd98.jpg" />\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="868px" datasizeheight="674px" dataX="92" dataY="629"   alt="image">\
          <img src="./images/16c6bfc6-dcaf-449b-8801-ec7528e39981.jpg" />\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="118px" datasizeheight="73px" dataX="13" dataY="60" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="118px" datasizeheight="73px" dataX="906" dataY="60" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="123px" datasizeheight="32px" dataX="893" dataY="14"  >\
          <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Text_10" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="152px" datasizeheight="42px" dataX="16" dataY="9" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_10_0">ReaLearn</span></div></div></div></div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="22px" dataX="914" dataY="19" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">משתמש</span></div></div></div></div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="94px" datasizeheight="22px" dataX="762" dataY="28" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">האתגרים שלי</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="139px" datasizeheight="22px" dataX="591" dataY="28" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">מערכת הלמידה שלי</span></div></div></div></div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="90px" datasizeheight="22px" dataX="457" dataY="28" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">הקבוצות שלי</span></div></div></div></div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="440px" datasizeheight="40px" dataX="416" dataY="19"  >\
          <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="200px" datasizeheight="40px" dataX="0" dataY="10"  >\
          <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle firer commentable non-processed"   datasizewidth="183px" datasizeheight="287px" dataX="0" dataY="387" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_3_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle firer commentable non-processed"   datasizewidth="183px" datasizeheight="287px" dataX="841" dataY="393" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_4_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="1017px" datasizeheight="2px" dataX="4" dataY="671" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 1017 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_2" class="shapewrapper shapewrapper-s-Line_2 non-processed"  rotationdeg="90" datasizewidth="506px" datasizeheight="11px" dataX="685" dataY="355" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_2" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 5 L 506 5"  marker-end="url(#end-marker-s-Line_2">\
                      </path>\
                  </g>\
              </g>\
              <defs>\
      			<marker id="end-marker-s-Line_2" class="open endmarker" orient="0" stroke-width="0px" viewBox="0 0 100 100" refY="50" preserveAspectRatio="none" markerUnits="userSpaceOnUse">\
      				<path d="M 39.688716 40.466926 39.818418 60.051881 7.9118028 79.24773 C -6.6058565 88.636494 5.3977603 106.07944 19.844358 97.146562 L 99.610893 50.324254 21.53048 3.7613489 C 4.631474 -8.1505951 -6.7257532 14.353316 7.6523994 20.881971 Z"></path>\
      			</marker>\
              </defs>\
          </svg>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;