var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1024" deviceHeight="768">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589075344964.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589075344964-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589075344964-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-55956c42-bb44-4ffb-b6e1-9bab21d74c22" class="screen growth-both devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="diycapt2" width="1024" height="768">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/55956c42-bb44-4ffb-b6e1-9bab21d74c22-1589075344964.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/55956c42-bb44-4ffb-b6e1-9bab21d74c22-1589075344964-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/55956c42-bb44-4ffb-b6e1-9bab21d74c22-1589075344964-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="1024px" datasizeheight="670px" dataX="0" dataY="0"   alt="image">\
          <img src="./images/b263609f-8e6e-4873-8f23-52795e92a6f7.jpg" />\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="713px" datasizeheight="46px" dataX="145" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="1016px" datasizeheight="88px" dataX="-1" dataY="56" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle firer commentable non-processed"   datasizewidth="152px" datasizeheight="439px" dataX="-1" dataY="231" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_3_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle firer commentable non-processed"   datasizewidth="160px" datasizeheight="439px" dataX="864" dataY="231" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_4_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="22px" dataX="914" dataY="19" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">משתמש</span></div></div></div></div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="94px" datasizeheight="22px" dataX="762" dataY="28" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">האתגרים שלי</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="139px" datasizeheight="22px" dataX="591" dataY="28" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">מערכת הלמידה שלי</span></div></div></div></div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="90px" datasizeheight="22px" dataX="457" dataY="28" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">הקבוצות שלי</span></div></div></div></div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="185px" datasizeheight="39px" dataX="421" dataY="116" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">תחומי למידה ברשת</span></div></div></div></div>\
      <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="101px" datasizeheight="26px" dataX="719" dataY="188" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">כל האתגרים</span></div></div></div></div>\
      <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="101px" datasizeheight="26px" dataX="574" dataY="188" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">כל התחומים</span></div></div></div></div>\
      <div id="s-Text_8" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="125px" datasizeheight="26px" dataX="388" dataY="188" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">אתגרים בשבילי</span></div></div></div></div>\
      <div id="s-Text_9" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="151px" datasizeheight="26px" dataX="188" dataY="188" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_9_0">אתגרים של חברים</span></div></div></div></div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="711px" datasizeheight="601px" dataX="158" dataY="663"   alt="image">\
          <img src="./images/02b6cbca-e9d6-4fa5-b047-3ab754bc7205.jpg" />\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="440px" datasizeheight="40px" dataX="416" dataY="19"  >\
          <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="354px" datasizeheight="47px" dataX="174" dataY="166"  >\
          <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="136px" datasizeheight="47px" dataX="701" dataY="166"  >\
          <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="123px" datasizeheight="32px" dataX="893" dataY="18"  >\
          <div class="clickableSpot"></div>\
      </div>\
      <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"  rotationdeg="90" datasizewidth="429px" datasizeheight="11px" dataX="741" dataY="341" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 5 L 429 5"  marker-end="url(#end-marker-s-Line_1">\
                      </path>\
                  </g>\
              </g>\
              <defs>\
      			<marker id="end-marker-s-Line_1" class="open endmarker" orient="0" stroke-width="0px" viewBox="0 0 100 100" refY="50" preserveAspectRatio="none" markerUnits="userSpaceOnUse">\
      				<path d="M 39.688716 40.466926 39.818418 60.051881 7.9118028 79.24773 C -6.6058565 88.636494 5.3977603 106.07944 19.844358 97.146562 L 99.610893 50.324254 21.53048 3.7613489 C 4.631474 -8.1505951 -6.7257532 14.353316 7.6523994 20.881971 Z"></path>\
      			</marker>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="69px" datasizeheight="27px" dataX="729" dataY="148"   alt="image" systemName="./images/1a47bf52-b1c9-4fc6-be11-5969a51952da.svg" overlay="#CBCBCB">\
          <?xml version="1.0" encoding="UTF-8"?>\
          <svg preserveAspectRatio=\'none\' width="23px" height="13px" viewBox="0 0 23 13" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
              <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              <title>Arrow Left</title>\
              <desc>Created with Sketch.</desc>\
              <defs></defs>\
              <g id="s-Image_3-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                  <g id="s-Image_3-Components" transform="translate(-658.000000, -518.000000)" fill="#CBCBCB">\
                      <g id="s-Image_3-Inputs" transform="translate(100.000000, 498.000000)">\
                          <g id="s-Image_3-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
                              <polyline transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0"></polyline>\
                          </g>\
                      </g>\
                  </g>\
              </g>\
          </svg>\
      </div>\
      <div id="s-Hotspot_6" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="682px" datasizeheight="1012px" dataX="174" dataY="251"  >\
          <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Text_10" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="152px" datasizeheight="42px" dataX="55" dataY="13" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_10_0">ReaLearn</span></div></div></div></div>\
      <div id="s-Text_11" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="130px" datasizeheight="22px" dataX="45" dataY="79" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_11_0">קישור לעוד חומרים</span></div></div></div></div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed"   datasizewidth="145px" datasizeheight="28px" dataX="24" dataY="76"  >\
          <div class="clickableSpot"></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;